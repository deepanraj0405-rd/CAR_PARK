#include <iostream>
using namespace std;

#define MAX 5

class Parking {
    string cars[MAX];
    int top;

public:
    Parking() {
        top = -1;
    }

    // Park a car
    void parkCar(string car) {
        if (top == MAX - 1) {
            cout << "Parking is FULL!\n";
            return;
        }

        top++;
        cars[top] = car;

        cout << car << " parked successfully.\n";
    }

    // Remove the last parked car
    void removeCar() {
        if (top == -1) {
            cout << "Parking is EMPTY!\n";
            return;
        }

        cout << cars[top] << " left the parking.\n";
        top--;
    }

    // Display parked cars
    void display() {
        if (top == -1) {
            cout << "Parking is EMPTY!\n";
            return;
        }

        cout << "\nCars in parking:\n";

        for (int i = top; i >= 0; i--) {
            cout << cars[i] << endl;
        }
    }
};

int main() {
    Parking parking;
    int choice;
    string car;

    do {
        cout << "\n===== NARROW PARKING =====\n";
        cout << "1. Park Car\n";
        cout << "2. Remove Car\n";
        cout << "3. Display Cars\n";
        cout << "4. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {

        case 1:
            cout << "Enter car name: ";
            cin >> car;
            parking.parkCar(car);
            break;

        case 2:
            parking.removeCar();
            break;

        case 3:
            parking.display();
            break;

        case 4:
            cout << "Program ended.\n";
            break;

        default:
            cout << "Invalid choice!\n";
        }

    } while (choice != 4);

    return 0;
}
